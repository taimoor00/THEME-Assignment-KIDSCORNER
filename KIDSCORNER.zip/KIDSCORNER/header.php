<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href=" <?php echo get_template_directory_uri(); ?>/css/style.css">
    <title><?php bloginfo( 'name' ); ?></title>

<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
     

		<!----------------Navbar ---------------->


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">
  
    <?php dynamic_sidebar( 'header_logo' ); ?>
  
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
     <ul class="navbar-nav ml-auto list-style-none">
        
        
        <?php  /* menu */
                    wp_nav_menu( array(
                                'menu'              => 'primary-menu',
                                'theme_location'    => 'primary-menu',
                                'depth'             => 5,
                                'container'         => 'div',
                                'container_class'   => 'collapse navbar-collapse navbar-ex1-collapse ',
                                'menu_class'        => 'nav navbar-nav  ',
                                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                'walker'            => new wp_bootstrap_navwalker())
                    ); 
                 ?>
        
        
       
     </ul> 
     <ul class = "list-unstyled">
      <li class="nav-item mx-5">
         <div class = "mt-2 ml-auto ex1 ">	
		<a href= "#"><i class="fab fa-twitter border border-dark rounded-circle p-1 mr-1 social-icon"></i></a>
		<a href= "#"><i class="fab fa-facebook-f border border-dark rounded-circle p-1 mr-1 social-icon"></i></a>
		<a href= "#"><i class="fab fa-instagram-square border border-dark rounded-circle p-1 social-icon"></i></a>
 	 </div>
      </li>   
     </ul   
  </div>
</nav>



		<!------------slider-------------->




<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
		<div class= "ml-5">
			<h4 class = "slider-text">a comfort corner <p class = "d-block"> for your child</p></h4>
			<p class = "sub-text p-2 px-5">LEARN MORE</p>
     		</div>
        	<img src="<?php echo get_template_directory_uri(); ?>/images/slider.png" class="d-block w-100" alt="Kids Corner slider-image">
		
	
    </div>

	
  </div>
</div>
