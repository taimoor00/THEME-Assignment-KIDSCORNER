

<div class ="container3 pb-5 text-white">
   <div class = "text intro text-center px-5 pt-4 ">
	<h4 class = "intro-text text-white">Get in Touch</h4>
	<p class = "p-2 px-5 mx-5 text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse in laoreet purus. Phasellus turpis lacus, feugiat eu tincidunt a, ultrices quis tellus. Ut eu justo a nunc gravida adipiscing.</p>
   </div>

		<!-------flex------->
 <div class ="d-flex flex-wrap">

    <div class = "col-md-5">
 	<h4 class = "intro-text px-5 mx-3">Contact Us</h4>
	

	<table>  
		<tr>
		<td><img src = "<?php echo get_template_directory_uri(); ?>/images/streetsign.png" class="px-5" style=" font-size:24px;"></td>	
	  	<td><p>4075, 13-B <br>
1 Finite Road
 <br>Chandigarh - 160099
 <br>India  </p><td>
		
		</tr>
	   	
		<tr>
			<td><img src = "<?php echo get_template_directory_uri(); ?>/images/mail.png" class="icon px-5"></td>
	 	 	<td><p class = "mx-3">mail@thesector.com</p> </td>
		</tr>
		
		<tr>
		 <td><img src = "<?php echo get_template_directory_uri(); ?>/images/phone.png" class="icon px-5"></td>
		 <td><p class = "mx-3">+91-001-767612345</p> <td>
		</tr>
	</table>
     </div>


    
    <div class = "col-md-7 text-left ">
 	<h4 class = "intro-text">Request a Quote</h4>

	<form class = " w-75 border-white">
  <div class="form-group">
    <label for="exampleFormControlInput1"> </label>
    <input type="email" class="form-control bg-transparent border-white rounded-0" id="exampleFormControlInput1" placeholder="Your Email">
  </div>
   <div class="form-group">
    <label for="exampleFormControlInput1"> </label>
    <input type="number" class="form-control bg-transparent border-white rounded-0" id="exampleFormControlInput1" placeholder="Your Phone No.">
  </div>

  
    <div class="form-group">
    <label for="exampleFormControlTextarea1"> </label>
    <textarea class="form-control bg-transparent border-white rounded-0" id="exampleFormControlTextarea1" rows="3" placeholder = "Your Message..."></textarea>
    </div>
<button class="btn btn-primary bg-transparent border-white rounded-0 px-4 strong" type="submit">SUBMIT</button>

</form>

    </div>

 </div>

</div>



		<!-----------Copyright-------->


<div class = "d-flex flex-wrap">

  <?php dynamic_sidebar( 'footer_col_1' ); ?>
  <div class = "p-4 mt-2 ml-auto mr-5 ex1">	 
	  <?php dynamic_sidebar( 'footer_col_2' ); ?>	         	
		
  </div>	 

 </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>